# MediTrack — Medicine Stock & Expiry Tracker

A full-stack college project with a separately organised frontend, Java Spring Boot REST backend, and MySQL database.

## Project structure
- `frontend/` — HTML, CSS and JavaScript user interface
- `backend/src/main/java/` — Spring Boot application, REST controller, service, entity and repository
- `backend/src/main/resources/` — backend configuration
- `database/schema.sql` — database and sample data script
- `pom.xml` — Maven dependencies and build configuration

## Features
- Add, view, edit and delete medicines
- Increase and decrease stock
- Dashboard totals and low-stock indicators
- Expiry and expiring-soon alerts (within 30 days)
- Search medicine inventory
- MySQL persistence through Spring Data JPA

## Requirements
- Java 17+
- Maven 3.6+
- MySQL 8+

## Run the database
1. Open MySQL Workbench or MySQL command line.
2. Run `database/schema.sql`.
3. Default local database settings are in `backend/src/main/resources/application.properties`.
4. For your own MySQL password, set environment variable `DB_PASSWORD` rather than committing a real password.

## Run the backend
From the project root:
```bash
mvn spring-boot:run
```
Backend base URL: `http://localhost:8080/api`

Useful endpoints:
- `GET /api/medicines`
- `GET /api/medicines?q=para`
- `POST /api/medicines`
- `PUT /api/medicines/{id}`
- `DELETE /api/medicines/{id}`
- `PATCH /api/medicines/{id}/stock?change=1`
- `GET /api/dashboard`

## Run the frontend
For local development, open `frontend/index.html` in a browser while the backend is running. If browser restrictions prevent API requests from a `file://` page, serve the frontend folder with a local static web server, or configure the frontend `API_BASE` in `frontend/app.js` to your deployed backend URL.

## Important deployment note
GitHub is used to store the source code. GitHub Pages can host the static frontend only; it cannot run this Java/Spring Boot backend or MySQL database. To make the full application work for other people over the internet, deploy the Spring Boot backend and MySQL database to a hosting provider, then update `API_BASE` in `frontend/app.js` to the backend URL. Do not expose database credentials in frontend files or commit real passwords.

## Viva explanation
- Frontend: HTML structures the page, CSS styles it, JavaScript calls backend REST APIs.
- Backend: Spring Boot receives HTTP requests; Controller exposes endpoints, Service contains business rules, Repository communicates with MySQL, and Entity maps to the `medicines` table.
- Database: MySQL stores medicine name, category, quantity, reorder level and expiry date.
- Low-stock rule: quantity is less than or equal to reorder level.
- Expiry rule: expiry date is within 30 days or already passed.
